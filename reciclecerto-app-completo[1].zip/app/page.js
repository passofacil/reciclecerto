import AppPrototype from "../components/AppPrototype";

export default function Home() {
  return <AppPrototype />;
}